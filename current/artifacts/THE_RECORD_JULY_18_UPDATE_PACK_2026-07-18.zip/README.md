# The Record — July 18, 2026 update package

This package contains nine dated entry packs, national and IN-6 briefs, current-entry JSON, and the source ledger.

Checked: 2026-07-18 12:00 PM EDT

The package is a current release layer, not a replacement for the complete historical archives.
