# Shreve joins House Appropriations with three subcommittee assignments

**Entry ID:** IN6-2026-07-18-003
**Date:** April 20–21, 2026
**Checked:** 2026-07-18 12:00 PM EDT
**Evidence state:** official committee and congressional-office records

The assignment increases the representative’s influence over justice, homeland-security, transportation, and housing spending.

## THE FACTS

- The House Appropriations Committee majority announced Shreve’s selection to the committee in April 2026.
- The announced subcommittee assignments were Commerce, Justice, Science and Related Agencies; Homeland Security; and Transportation, Housing and Urban Development and Related Agencies.
- IN‑6 encompasses 11 counties across central and eastern Indiana, and Shreve’s official site lists district offices in Greenwood and Richmond.

## SIGNIFICANCE

Appropriations membership increases both power and the need for traceability. Votes, earmark requests, agency oversight, private meetings, and district outcomes should be linked so constituents can distinguish influence claimed from influence demonstrated.

## GOALPOST / RESPONSE

Committee membership is evidence of institutional power, not evidence that every requested project or policy outcome has been achieved. The relevant accountability test is what the member requests, changes, votes for, and ultimately delivers.

## SOURCES

- [House Appropriations — Shreve committee assignment](https://appropriations.house.gov/news/press-releases/cole-welcomes-rep-jefferson-shreve-appropriations-committee) — official committee statement
- [Rep. Shreve — official district description and offices](https://shreve.house.gov/about/our-district) — official current reference

## SCOPE NOTE

This entry is a dated, source-bound update. It does not by itself revalidate every legacy entry in The Record.
